var structosmo__jibuf__msgb__cb =
[
    [ "old_cb", "structosmo__jibuf__msgb__cb.html#afd68dae90ec0b4a1ad01a674f155d4e2", null ],
    [ "ts", "structosmo__jibuf__msgb__cb.html#a0030f8093b8532e14b10221d60383bc5", null ]
];