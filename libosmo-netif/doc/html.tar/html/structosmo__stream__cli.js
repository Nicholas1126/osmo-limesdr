var structosmo__stream__cli =
[
    [ "addr", "structosmo__stream__cli.html#a6adcfeda508ec593e675439d629a7649", null ],
    [ "connect_cb", "structosmo__stream__cli.html#ad8a0379dc5c287ec8724f1f69a349b1d", null ],
    [ "data", "structosmo__stream__cli.html#a2184b319365317b03c987d5277d23003", null ],
    [ "disconnect_cb", "structosmo__stream__cli.html#a8077cee10ab7ce56a9a7e319c14b9f99", null ],
    [ "flags", "structosmo__stream__cli.html#a671bdf5bb63d5018d9fba64cd46f86c8", null ],
    [ "local_addr", "structosmo__stream__cli.html#ac443a372b4af9aa07c36e97cade81ca6", null ],
    [ "local_port", "structosmo__stream__cli.html#ac7b73e33d3984e5f1b7630c245c803c4", null ],
    [ "ofd", "structosmo__stream__cli.html#a4accf4d91be7cd280b04d3a016769977", null ],
    [ "port", "structosmo__stream__cli.html#a45b9970e789ab5694b3955e64881fe88", null ],
    [ "proto", "structosmo__stream__cli.html#a5b9f6feee81f5710f8bd071f1fca0ad5", null ],
    [ "read_cb", "structosmo__stream__cli.html#a7fb0e86989dc635fbd48d47518c3772e", null ],
    [ "reconnect_timeout", "structosmo__stream__cli.html#aba8a039b9671714f75f0d25f68be59de", null ],
    [ "state", "structosmo__stream__cli.html#a7f4473e13d4f045eb51a856195d8c237", null ],
    [ "timer", "structosmo__stream__cli.html#a7624330c3f4951c363d6df3765ff18fc", null ],
    [ "tx_queue", "structosmo__stream__cli.html#a3a41ee68801b72a98480b846361af2fb", null ],
    [ "write_cb", "structosmo__stream__cli.html#a9ada74a5b550df47b11aab680013017f", null ]
];