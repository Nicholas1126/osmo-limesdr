var structosmo__dgram__rx =
[
    [ "addr", "structosmo__dgram__rx.html#a535d49708ee6b7f249ca58082b2bb8c4", null ],
    [ "cb", "structosmo__dgram__rx.html#a4810048d7287542504c7292aa3bd995d", null ],
    [ "data", "structosmo__dgram__rx.html#a729c167ee1930b83777aa5f480eb8204", null ],
    [ "flags", "structosmo__dgram__rx.html#a473bbab3a801abe77374f6346a8aaafb", null ],
    [ "ofd", "structosmo__dgram__rx.html#a544bbbb72a4045a1f2825dbad7d40868", null ],
    [ "port", "structosmo__dgram__rx.html#ad1d56701eaf83e6f866bbfdf00d178fa", null ]
];