var searchData=
[
  ['ipa_5fhead',['ipa_head',['../structipa__head.html',1,'']]],
  ['ipa_5fhead_5fext',['ipa_head_ext',['../structipa__head__ext.html',1,'']]]
];
