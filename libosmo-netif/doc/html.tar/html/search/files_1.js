var searchData=
[
  ['jibuf_2ec',['jibuf.c',['../jibuf_8c.html',1,'']]],
  ['jibuf_2eh',['jibuf.h',['../jibuf_8h.html',1,'']]]
];
