var searchData=
[
  ['baudrate2termbits',['baudrate2termbits',['../structbaudrate2termbits.html',1,'']]]
];
