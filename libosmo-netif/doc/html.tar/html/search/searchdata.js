var indexSectionsWithContent =
{
  0: "abdijmors",
  1: "abior",
  2: "djos",
  3: "o",
  4: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Modules"
};

