var structosmo__rtp__handle =
[
    [ "last_tv", "structosmo__rtp__handle.html#aa2df58d7e90ee2ac83f7f05c75eda4bd", null ],
    [ "sequence", "structosmo__rtp__handle.html#ac1bcf91bc4473357bb3b78fcde602b36", null ],
    [ "ssrc", "structosmo__rtp__handle.html#a312ce9d6be4a6d6b705da020c137249d", null ],
    [ "timestamp", "structosmo__rtp__handle.html#a5217f907f43e45c1c45e2e487726b94e", null ],
    [ "tx", "structosmo__rtp__handle.html#a555fc8286778174716b76c67e106cc9c", null ]
];