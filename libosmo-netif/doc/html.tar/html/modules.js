var modules =
[
    [ "Osmocom Jitter Buffer", "group__jibuf.html", "group__jibuf" ],
    [ "Osmocom Multiplex Protocol", "group__osmux.html", "group__osmux" ],
    [ "Osmocom Stream Socket", "group__stream.html", "group__stream" ],
    [ "Osmocom Datagram Socket", "group__datagram.html", "group__datagram" ]
];