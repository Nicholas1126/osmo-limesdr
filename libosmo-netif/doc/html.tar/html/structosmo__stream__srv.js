var structosmo__stream__srv =
[
    [ "cb", "structosmo__stream__srv.html#a5e2827dbf42603372bcd2d127a9a7d68", null ],
    [ "closed_cb", "structosmo__stream__srv.html#a80d01e74ab3a0782a4cc891c2f500248", null ],
    [ "data", "structosmo__stream__srv.html#a549ad7d39ea797afc86da4497ee8b5a3", null ],
    [ "flags", "structosmo__stream__srv.html#ac71e48886a24e00f73543b5cf3bdcc58", null ],
    [ "ofd", "structosmo__stream__srv.html#a5bebfa86d9726ea54ebcdb757feacdd6", null ],
    [ "srv", "structosmo__stream__srv.html#ab5f8b381f95a1e6eb1f5301750ced81c", null ],
    [ "tx_queue", "structosmo__stream__srv.html#a32c1988d4336214cc07f53c1b3ee276d", null ]
];