var structosmux__tx__handle =
[
    [ "data", "structosmux__tx__handle.html#a2a608273e23904a15cae6a5e05bcc2eb", null ],
    [ "msg", "structosmux__tx__handle.html#a392a6947cfc7c89608943e1558b5553e", null ],
    [ "timer", "structosmux__tx__handle.html#a9ad54f4f466be68596dbd49cb1278f9e", null ],
    [ "tx_cb", "structosmux__tx__handle.html#ad668c50097e6dd4268d87f646f8b1ac1", null ]
];