var structipa__head =
[
    [ "data", "structipa__head.html#a4a4616c284c8fdb6598ee46fb616ae90", null ],
    [ "len", "structipa__head.html#a9bbcada25e9b0877527f6cb0a643aa0c", null ],
    [ "proto", "structipa__head.html#af9d1353ce62c64cb88070fe9dae29906", null ]
];