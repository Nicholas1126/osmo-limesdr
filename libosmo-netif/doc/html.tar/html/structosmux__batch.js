var structosmux__batch =
[
    [ "circuit_list", "structosmux__batch.html#a842f0efe1b94f291d749dcb7f8b4ecac", null ],
    [ "ndummy", "structosmux__batch.html#ad30c9a1c9f859a35277f8159fd899d46", null ],
    [ "nmsgs", "structosmux__batch.html#a3ea13cf1fa7e69a14c240456de2ab0b8", null ],
    [ "osmuxh", "structosmux__batch.html#a6eba2a9e5109b28a26d4a73818573cb5", null ],
    [ "remaining_bytes", "structosmux__batch.html#a234077c85b52c7ac83f62df353edda30", null ],
    [ "seq", "structosmux__batch.html#a167c6659b6740ad9fd2e47c4fe520d5b", null ],
    [ "timer", "structosmux__batch.html#aeb47541753d01cd0614b8d192ac9f8a7", null ]
];