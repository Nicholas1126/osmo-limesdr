var structosmo__rs232 =
[
    [ "baudrate", "structosmo__rs232.html#af7674285561fa6d3ce65b7aa9a5802a8", null ],
    [ "cb", "structosmo__rs232.html#ac315b9c72f44a9e4afb922131363f7e6", null ],
    [ "cfg", "structosmo__rs232.html#a41ef0fb7725e18447c8fabc0d1428c60", null ],
    [ "delay_us", "structosmo__rs232.html#a39d074f794fb4d9046fd34254699f9dd", null ],
    [ "ofd", "structosmo__rs232.html#a812a1e053b281246ec1fd42d61bda1bd", null ],
    [ "read", "structosmo__rs232.html#a2eb52a22e425b10e1af46e493a3c6078", null ],
    [ "serial_port", "structosmo__rs232.html#a6a02021fd4760addd91862e1ab38d6ae", null ],
    [ "tx_queue", "structosmo__rs232.html#acd209ed3eded625ce61c7a84487cd3df", null ],
    [ "tx_timer", "structosmo__rs232.html#a807b616c3d96a2988a48cf46d023c058", null ]
];