var structbaudrate2termbits =
[
    [ "def", "structbaudrate2termbits.html#a65bafeff4b6ee135e73ec863bd13d2ae", null ],
    [ "rate", "structbaudrate2termbits.html#aca5e0bd4d1bb8ca39005d057c98f4ed1", null ]
];