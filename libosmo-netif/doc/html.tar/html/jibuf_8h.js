var jibuf_8h =
[
    [ "osmo_jibuf_dequeue_cb", "group__jibuf.html#ga78eb735a1f6c3dd8b6478ded3db60652", null ],
    [ "osmo_jibuf_alloc", "group__jibuf.html#ga20592f230f9d1233752fd318996f2c9d", null ],
    [ "osmo_jibuf_delete", "group__jibuf.html#gacdac7beaf3d97543718ddfa33123fb7e", null ],
    [ "osmo_jibuf_empty", "group__jibuf.html#gae73a3b805b83f453339adeee9cdfaba4", null ],
    [ "osmo_jibuf_enable_skew_compensation", "group__jibuf.html#ga096e87b2dbdade72c35d51a51fe57839", null ],
    [ "osmo_jibuf_enqueue", "group__jibuf.html#ga522165ddc51578436ae2d26691fa7ec0", null ],
    [ "osmo_jibuf_set_dequeue_cb", "group__jibuf.html#ga3a8213fe8bed42d649fcb1c8d13e23d8", null ],
    [ "osmo_jibuf_set_max_delay", "group__jibuf.html#ga5e84571c3348525b6ad647a22cd2581d", null ],
    [ "osmo_jibuf_set_min_delay", "group__jibuf.html#gabcd63f39049bc4d6b3541a674b78963d", null ],
    [ "__attribute__", "group__jibuf.html#ga1c12dad616e7250646df9c6163c65f6c", null ]
];