var structosmo__dgram__tx =
[
    [ "addr", "structosmo__dgram__tx.html#adbcdc50c4e16ad9e4209761765363f64", null ],
    [ "data", "structosmo__dgram__tx.html#a7b337ca1e6e50f9dc1a4f6bf4c8270ef", null ],
    [ "flags", "structosmo__dgram__tx.html#acebe704c80145f6549e8f2e3720378ff", null ],
    [ "local_addr", "structosmo__dgram__tx.html#a47a7a07deb207a6f6803f89dd88a16a4", null ],
    [ "local_port", "structosmo__dgram__tx.html#a80d3e5427bf2b7a557b15918e68bae91", null ],
    [ "ofd", "structosmo__dgram__tx.html#a207be20fb8b46dea43f0d00bb3a11d62", null ],
    [ "port", "structosmo__dgram__tx.html#a14bd39a91c3f3f59429b1975e2c8ba83", null ],
    [ "tx_queue", "structosmo__dgram__tx.html#a2ac4a03c71e730709d44f6d78fb2854f", null ],
    [ "write_cb", "structosmo__dgram__tx.html#a35c03a112f6a745f079e58be365c2df0", null ]
];