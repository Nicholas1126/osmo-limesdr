var structosmux__input__state =
[
    [ "add_osmux_hdr", "structosmux__input__state.html#ae5283bdb09cdf2f9b7d42e85a4fb0ad5", null ],
    [ "amr_payload_len", "structosmux__input__state.html#a89e7e22ff611f563081ae3a7f7ad7e2c", null ],
    [ "amrh", "structosmux__input__state.html#af314656bec412f19390db5bb9bdc8bbb", null ],
    [ "ccid", "structosmux__input__state.html#a64b1a679d9e0c89438bae60d970477de", null ],
    [ "msg", "structosmux__input__state.html#a680977f2f95a27089b55f318c485bc9f", null ],
    [ "out_msg", "structosmux__input__state.html#a63f3aa8f0abf13635f5825aca005e824", null ],
    [ "rtph", "structosmux__input__state.html#a07c397296785e0c29535bc2d2bc7db7a", null ]
];