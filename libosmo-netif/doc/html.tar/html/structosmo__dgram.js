var structosmo__dgram =
[
    [ "data", "structosmo__dgram.html#a42d2003165caffffc96e9e22fef8db11", null ],
    [ "read_cb", "structosmo__dgram.html#a102cca53faaec53af52f7ae59ec8fc7d", null ],
    [ "rx", "structosmo__dgram.html#a3d782cbe3037ab44f4fa68834827dfcf", null ],
    [ "tx", "structosmo__dgram.html#ad1f75658d60ee1abab43d801494ba419", null ]
];