var structosmux__in__handle =
[
    [ "batch_factor", "structosmux__in__handle.html#a19f745e91cf6cde79d37311775e08474", null ],
    [ "batch_size", "structosmux__in__handle.html#a368e53721d8272b6f9d62b398db0402d", null ],
    [ "data", "structosmux__in__handle.html#a5e956516034fe24c6e52b481d994c8c5", null ],
    [ "deliver", "structosmux__in__handle.html#aef1dba895e5ce6443082e3878c3704c8", null ],
    [ "input_rtp_bytes", "structosmux__in__handle.html#afe1c2a7c6701111628182d18739c7309", null ],
    [ "input_rtp_msgs", "structosmux__in__handle.html#adb2b61b603306db801901191a56fd6fe", null ],
    [ "internal_data", "structosmux__in__handle.html#a882fe396ba5bf4e9cef37bed4d9ded04", null ],
    [ "osmux_seq", "structosmux__in__handle.html#a1ba076a41ef9c3413665b7444c6521cc", null ],
    [ "output_osmux_bytes", "structosmux__in__handle.html#aa8054bc55d3996c8215792994529c9d2", null ],
    [ "output_osmux_msgs", "structosmux__in__handle.html#ae078b561edeb6f81c63638a73b2e5211", null ],
    [ "stats", "structosmux__in__handle.html#a37f3e33e1cd6b6fbead90d22e38193b2", null ]
];