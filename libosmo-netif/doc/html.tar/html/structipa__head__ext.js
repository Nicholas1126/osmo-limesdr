var structipa__head__ext =
[
    [ "data", "structipa__head__ext.html#ab32f6ef1a38d6d8fc23a2a57a17b376c", null ],
    [ "proto", "structipa__head__ext.html#a625ac01b022643530d495a1fd661a4a4", null ]
];