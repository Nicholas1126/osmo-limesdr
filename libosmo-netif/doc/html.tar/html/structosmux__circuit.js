var structosmux__circuit =
[
    [ "ccid", "structosmux__circuit.html#a2cfac1921724ba15322226462517e92e", null ],
    [ "dummy", "structosmux__circuit.html#a02ab8c79e4f705eeba71a77aa482d8cb", null ],
    [ "head", "structosmux__circuit.html#a815dfd8ed9833224b9774cf8277402ca", null ],
    [ "msg_list", "structosmux__circuit.html#a996a9d51bd5bb358aafe208a5725978e", null ],
    [ "nmsgs", "structosmux__circuit.html#aa77e3a7965e6b2a20ecf25930fa24a97", null ]
];