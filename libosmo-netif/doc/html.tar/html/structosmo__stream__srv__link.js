var structosmo__stream__srv__link =
[
    [ "accept_cb", "structosmo__stream__srv__link.html#a9ead575ef31a1e835f0806eaf31c4c9f", null ],
    [ "addr", "structosmo__stream__srv__link.html#a6c0ff0391f4c3705b85964f0e13a7379", null ],
    [ "data", "structosmo__stream__srv__link.html#aa05e87bd15c3a1cbd3b4b3a172da0f4f", null ],
    [ "flags", "structosmo__stream__srv__link.html#ab65902f1c69408604611f5f2b2dbad17", null ],
    [ "ofd", "structosmo__stream__srv__link.html#a4989e1e6cbc6d6676ba1ed06b741a05f", null ],
    [ "port", "structosmo__stream__srv__link.html#ae2e02ca467db119118d839cc0a4f6eb4", null ],
    [ "proto", "structosmo__stream__srv__link.html#af6b6972fd66cef3e6d3ef6a6fe790a5f", null ]
];