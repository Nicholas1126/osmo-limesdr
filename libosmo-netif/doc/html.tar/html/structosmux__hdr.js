var structosmux__hdr =
[
    [ "circuit_id", "structosmux__hdr.html#a281e689bfae94a2034769a96e48dc64b", null ],
    [ "seq", "structosmux__hdr.html#a196aed00388a65b126a72a76680699b8", null ]
];