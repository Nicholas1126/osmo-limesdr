var structosmo__ipa__unit =
[
    [ "bts_id", "structosmo__ipa__unit.html#a9b072b5702ee31e3ca12323a99bf5b7d", null ],
    [ "data", "structosmo__ipa__unit.html#aafa110002f823370332cc2544b86e8b9", null ],
    [ "head", "structosmo__ipa__unit.html#af6e4d3706264d8ec483a08cff456dc2c", null ],
    [ "hwvers", "structosmo__ipa__unit.html#a204bb938ce6be0fc1f263387d226ab2d", null ],
    [ "location1", "structosmo__ipa__unit.html#a9de8d7ec217c28fb22081d76d0348d92", null ],
    [ "location2", "structosmo__ipa__unit.html#a45eda8d32a6c6aa6e235f8ef710373fc", null ],
    [ "mac_addr", "structosmo__ipa__unit.html#a2492ae682d3d902761e0d2ff5038642e", null ],
    [ "name", "structosmo__ipa__unit.html#a43b0bf6664e231d4e8891df310ce5a10", null ],
    [ "serno", "structosmo__ipa__unit.html#ae1d5958e1ca9db7f29f62ee535f40057", null ],
    [ "site_id", "structosmo__ipa__unit.html#a2b3a37c6d15fbf8a8ef4b8c42b55a1ad", null ],
    [ "swvers", "structosmo__ipa__unit.html#aafccbfb530d5e94a5f9cf1b20824b10d", null ],
    [ "trx_id", "structosmo__ipa__unit.html#afa861e7893b14cc5de1d5e495c183d16", null ]
];